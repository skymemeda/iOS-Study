//
//  LRHMeTopViewCell.m
//  YingKeDemo
//
//  Created by liranhui on 2017/3/6.
//  Copyright © 2017年 liranhui. All rights reserved.
//

#import "LRHMeTopViewCell.h"
#import "Masonry.h"
@interface LRHMeTopViewCell()


@end
@implementation LRHMeTopViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.backView = [LRHMeTopView loadTopView];
    [self.contentView addSubview:self.backView];
    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.contentView);
    }];
    // Initialization code
}
+(instancetype)loadCell
{
    return [[[NSBundle mainBundle] loadNibNamed:@"LRHMeTopViewCell" owner:self options:nil] lastObject];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

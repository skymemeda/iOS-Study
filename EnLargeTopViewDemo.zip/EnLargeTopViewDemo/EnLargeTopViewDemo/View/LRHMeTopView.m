//
//  LRHMeTopView.m
//  YingKeDemo
//
//  Created by liranhui on 2017/3/3.
//  Copyright © 2017年 liranhui. All rights reserved.
//

#import "LRHMeTopView.h"
@interface LRHMeTopView()
@property (strong, nonatomic) IBOutlet UILabel *namelabel;
@property (strong, nonatomic) IBOutlet UIImageView *iconImageView;


@end
@implementation LRHMeTopView

+(instancetype)loadTopView
{
    return [[[NSBundle mainBundle] loadNibNamed:@"LRHMeTopView" owner:self options:nil] lastObject];
}
@end

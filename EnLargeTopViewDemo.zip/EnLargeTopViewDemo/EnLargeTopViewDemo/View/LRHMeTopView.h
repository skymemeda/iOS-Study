//
//  LRHMeTopView.h
//  YingKeDemo
//
//  Created by liranhui on 2017/3/3.
//  Copyright © 2017年 liranhui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LRHMeTopView : UIView
+(instancetype)loadTopView;
-(void)updateUserInfo;
@end

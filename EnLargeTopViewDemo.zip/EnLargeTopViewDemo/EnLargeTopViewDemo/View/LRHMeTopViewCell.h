//
//  LRHMeTopViewCell.h
//  YingKeDemo
//
//  Created by liranhui on 2017/3/6.
//  Copyright © 2017年 liranhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LRHMeTopView.h"
@interface LRHMeTopViewCell : UITableViewCell
@property (strong, nonatomic)LRHMeTopView *backView;
+(instancetype)loadCell;
@end

//
//  main.m
//  EnLargeTopViewDemo
//
//  Created by liranhui on 2017/3/6.
//  Copyright © 2017年 liranhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

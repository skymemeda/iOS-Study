//
//  LRHSetting.h
//  YingKeDemo
//
//  Created by liranhui on 2017/3/3.
//  Copyright © 2017年 liranhui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LRHSetting : NSObject
@property(nonatomic,strong)NSString    *title;
@property(nonatomic,strong)NSString    *subtitle;
@end

//
//  LRHMeViewController.m
//  YingKeDemo
//
//  Created by liranhui on 2017/3/3.
//  Copyright © 2017年 liranhui. All rights reserved.
//

#import "LRHMeViewController.h"
#import "LRHMeTopView.h"
#import "LRHSetting.h"
#import "LRHMeTopViewCell.h"
#import "LRHMacro.h"
#define HeaderViewHeight DEVICE_HEIGHT*0.4
@interface LRHMeViewController ()
@property(nonatomic,strong)UITableView         *tableView;
@property(nonatomic,strong)NSArray             *dataList;
@property(nonatomic,strong)LRHMeTopViewCell    *topViewCell;
@property(nonatomic,strong)UIView              *bottomView;
@end

@implementation LRHMeViewController

- (NSArray *)dataList
{
    if(_dataList == nil)
    {
        _dataList = [[NSArray alloc]init];
    }
    return _dataList;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    //加载数据
    [self loadData];
}
- (void)initUI
{
    //scrollView  对navibar的影响
    self.automaticallyAdjustsScrollViewInsets = NO;
    //创建tableView
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, DEVICE_WIDTH, DEVICE_HEIGHT) style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    [self.tableView registerNib:[UINib nibWithNibName:@"LRHMeTopViewCell" bundle:nil] forCellReuseIdentifier:@"MeTopCell"];
    //退出登录按钮
    UIView *quitView = [[UIView alloc]initWithFrame:CGRectMake(0, DEVICE_HEIGHT-120, DEVICE_WIDTH, 110)];
    self.bottomView = quitView;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(20, 20,quitView.frame.size.width-40,50);
    [button setTitle:@"退出登录" forState:UIControlStateNormal];
    button.backgroundColor = [UIColor orangeColor];
    [button addTarget:self action:@selector(quit:) forControlEvents:UIControlEventTouchUpInside];
    [quitView addSubview:button];
    self.tableView.tableFooterView = quitView;
}
- (void)loadData
{
    //获取tableView 数据
    LRHSetting *setting1 = [[LRHSetting alloc]init];
    setting1.title = @"映票贡献榜";
    setting1.subtitle = @"";
    
    LRHSetting *setting2 = [[LRHSetting alloc]init];
    setting2.title = @"短视频";
    setting2.subtitle = @"";

    LRHSetting *setting3 = [[LRHSetting alloc]init];
    setting3.title = @"收益";
    setting3.subtitle = @"0 映票";
    LRHSetting *setting4 = [[LRHSetting alloc]init];
    setting4.title = @"账户";
    setting4.subtitle = @"0 钻石";
    
    LRHSetting *setting5 = [[LRHSetting alloc]init];
    setting5.title = @"等级";
    setting5.subtitle = @"1级";
    LRHSetting *setting6 = [[LRHSetting alloc]init];
    setting6.title = @"实名认证";
    setting6.subtitle = @"";
    LRHSetting *setting7 = [[LRHSetting alloc]init];
    setting7.title = @"设置";
    setting7.subtitle = @"";
    
    
    NSMutableArray *array1 = [NSMutableArray arrayWithObjects:@"",setting1,setting2,setting3,setting4, nil];
    NSMutableArray *array2 = [NSMutableArray arrayWithObjects:setting5,setting6,nil];
    NSMutableArray *array3 = [NSMutableArray arrayWithObjects:setting7,nil];
    self.dataList = @[array1,array2,array3];
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
    //隐藏 状态栏
    [self prefersStatusBarHidden];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBarHidden = NO;
}
- (void)quit:(UIButton*)button
{
    NSLog(@"退出登录");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGFloat yOffset = self.tableView.contentOffset.y;
    if(yOffset<0)
    {
        CGFloat height = ABS(yOffset)+HeaderViewHeight;
        self.topViewCell.frame = CGRectMake(0,yOffset, DEVICE_WIDTH, height);
    }
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [UIView animateWithDuration:0.2 animations:^{
        CGRect frame = self.topViewCell.frame;
        frame.size.height = HeaderViewHeight;
        self.topViewCell.frame = frame;
        [self.tableView reloadData];
    }];
}
#pragma UITableViewDelegate UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataList.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.dataList[section] count];

    
}
- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0 && indexPath.row == 0)
    {
        LRHMeTopViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MeTopCell"];
        if(!cell)
        {
            cell = [LRHMeTopViewCell loadCell];
        }
        self.topViewCell = cell;
        return cell;
    }
    else
    {
        UITableViewCell* cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"MeCell"];
        LRHSetting *setting = self.dataList[indexPath.section][indexPath.row];
        cell.textLabel.font = [UIFont systemFontOfSize:13];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:13];
        cell.textLabel.text = setting.title;
        cell.detailTextLabel.text = setting.subtitle;
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        return cell;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0 && indexPath.row == 0)
    {
        return HeaderViewHeight;
    }
    else
    {
        return 50;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if(section == self.dataList.count)
    {
       return self.bottomView.bounds.size.height;
    }
    else
    {
        return 1;
    }
}
- (UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    if(section == self.dataList.count)
    {
        return self.bottomView;
    }
    else
    {
        return nil;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(section == 0)
    {
        return 0;
    }
    else
    {
        return 10;
    }
    
}
@end

//
//  LRHMacro.m
//  YingKeDemo
//
//  Created by liranhui on 2017/2/27.
//  Copyright © 2017年 liranhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#define DEVICE_WIDTH [[UIScreen mainScreen] bounds].size.width
#define DEVICE_HEIGHT [[UIScreen mainScreen] bounds].size.height
